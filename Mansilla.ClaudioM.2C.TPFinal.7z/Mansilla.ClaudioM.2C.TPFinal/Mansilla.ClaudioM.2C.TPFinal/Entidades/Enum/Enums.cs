﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Enum
{
    public enum EPirotecnia {Estrellita, Chasquibum, CañitaVoladora, Bengala, Petardo, Mortero}

    public enum ESangreGrupo {A,B,AB,O}

    public enum ESangreFactor {Positivo, Negativo}

    public enum EEstadoAtencion {Atendido, Pendiente}


}
