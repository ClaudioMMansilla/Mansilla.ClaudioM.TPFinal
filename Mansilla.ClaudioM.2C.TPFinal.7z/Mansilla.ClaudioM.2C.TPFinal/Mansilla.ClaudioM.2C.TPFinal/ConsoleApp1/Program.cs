﻿using Entidades.DataBase;
using Entidades.Enum;
using Entidades.MetodosExtencion;
using Entidades.Modelos;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Paciente p = new Paciente();
            p = ADOPacientes.GetPacienteByDni(9122018);
            Console.WriteLine(p.Nombre + p.Apellido);

            //Console.WriteLine($"Edad: {p.CalcularEdad()}");
            string hola = "30333444";
            int chau = hola.CastearDni();
            Console.WriteLine(chau);

            string fecha = "14-12-1990";
            DateTime date = fecha.CastearFechaNac();
            Console.WriteLine(fecha);



        }
    }
}